import math
import torch
from torch import autograd as autograd
from torch import nn as nn
from torch.nn import functional as F
import torchvision
import pytorch_msssim
import numpy as np

# from losses.vgg_arch import VGGFeatureExtractor
from losses.loss_utils import weighted_loss
#from basicsr.metrics.lpips.lpips import LPIPS

_reduction_modes = ['none', 'mean', 'sum']


@weighted_loss
def l1_loss(pred, target):
    return F.l1_loss(pred, target, reduction='none')


@weighted_loss
def mse_loss(pred, target):
    return F.mse_loss(pred, target, reduction='none')

@weighted_loss
def log_mse_loss(pred, target):
    return torch.log(F.mse_loss(pred, target, reduction='none'))


@weighted_loss
def charbonnier_loss(pred, target, eps=1e-12):
    return torch.sqrt((pred - target)**2 + eps)

@weighted_loss
def psnr_loss(pred, target): # NCHW
    mseloss = F.mse_loss(pred, target, reduction='none').mean((1,2,3))
    psnr_val = 10 * torch.log10(1 / mseloss).mean().item()
    return psnr_val

class PSNRLoss(nn.Module):

    def __init__(self, loss_weight=1.0):
        super(PSNRLoss, self).__init__()
        self.loss_weight = loss_weight

    def forward(self, pred, target, weight=None, **kwargs):
        """
        Args:
            pred (Tensor): of shape (N, C, H, W). Predicted tensor.
            target (Tensor): of shape (N, C, H, W). Ground truth tensor.
            weight (Tensor, optional): of shape (N, C, H, W). Element-wise
                weights. Default: None.
        """
        return self.loss_weight * psnr_loss(pred, target, weight) * -1.0 

class L1Loss(nn.Module):
    """L1 (mean absolute error, MAE) loss.

    Args:
        loss_weight (float): Loss weight for L1 loss. Default: 1.0.
        reduction (str): Specifies the reduction to apply to the output.
            Supported choices are 'none' | 'mean' | 'sum'. Default: 'mean'.
    """

    def __init__(self, loss_weight=1.0, reduction='mean'):
        super(L1Loss, self).__init__()
        if reduction not in ['none', 'mean', 'sum']:
            raise ValueError(f'Unsupported reduction mode: {reduction}. '
                             f'Supported ones are: {_reduction_modes}')

        self.loss_weight = loss_weight
        self.reduction = reduction

    def forward(self, pred, target, weight=None, **kwargs):
        """
        Args:
            pred (Tensor): of shape (N, C, H, W). Predicted tensor.
            target (Tensor): of shape (N, C, H, W). Ground truth tensor.
            weight (Tensor, optional): of shape (N, C, H, W). Element-wise
                weights. Default: None.
        """
        return self.loss_weight * l1_loss(
            pred, target, weight, reduction=self.reduction)


class MSELoss(nn.Module):
    """MSE (L2) loss.

    Args:
        loss_weight (float): Loss weight for MSE loss. Default: 1.0.
        reduction (str): Specifies the reduction to apply to the output.
            Supported choices are 'none' | 'mean' | 'sum'. Default: 'mean'.
    """

    def __init__(self, loss_weight=1.0, reduction='mean'):
        super(MSELoss, self).__init__()
        if reduction not in ['none', 'mean', 'sum']:
            raise ValueError(f'Unsupported reduction mode: {reduction}. '
                             f'Supported ones are: {_reduction_modes}')

        self.loss_weight = loss_weight
        self.reduction = reduction

    def forward(self, pred, target, weight=None, **kwargs):
        """
        Args:
            pred (Tensor): of shape (N, C, H, W). Predicted tensor.
            target (Tensor): of shape (N, C, H, W). Ground truth tensor.
            weight (Tensor, optional): of shape (N, C, H, W). Element-wise
                weights. Default: None.
        """
        
        return self.loss_weight * mse_loss(
            pred, target, weight, reduction=self.reduction)

class FrequencyLoss(nn.Module):
    '''
    Calculates the amplitude of frequencies loss.
    '''
    def __init__(self, loss_weight = 0.01, criterion ='l2', reduction = 'mean'):
        super(FrequencyLoss, self).__init__()
        if reduction not in ['none', 'mean', 'sum']:
            raise ValueError(f'Unsupported reduction mode: {reduction}. '
                             f'Supported ones are: {_reduction_modes}')       
        self.loss_weight = loss_weight
        self.reduction = reduction

        if criterion == 'l1':
            self.criterion = nn.L1Loss(reduction=reduction)
        elif criterion == 'l2':
            self.criterion = nn.MSELoss(reduction=reduction)
        else:
            raise NotImplementedError('Unsupported criterion loss')

    def forward(self, pred, target, weight=None, **kwargs):
        """
        Args:
            pred (Tensor): of shape (N, C, H, W). Predicted tensor.
            target (Tensor): of shape (N, C, H, W). Ground truth tensor.
            weight (Tensor, optional): of shape (N, C, H, W). Element-wise
                weights. Default: None.
        """
        pred_freq = self.get_fft_amplitude(pred)
        target_freq = self.get_fft_amplitude(target)
        
        return self.loss_weight * self.criterion(pred_freq, target_freq)

    def get_fft_amplitude(self, inp):
        
        inp_freq = torch.fft.rfft2(inp, norm='backward')
        amp = torch.abs(inp_freq)
        return amp

class CharbonnierLoss(nn.Module):
    """Charbonnier loss (one variant of Robust L1Loss, a differentiable
    variant of L1Loss).

    Described in "Deep Laplacian Pyramid Networks for Fast and Accurate
        Super-Resolution".

    Args:
        loss_weight (float): Loss weight for L1 loss. Default: 1.0.
        reduction (str): Specifies the reduction to apply to the output.
            Supported choices are 'none' | 'mean' | 'sum'. Default: 'mean'.
        eps (float): A value used to control the curvature near zero.
            Default: 1e-12.
    """

    def __init__(self, loss_weight=1.0, reduction='mean', eps=1e-12):
        super(CharbonnierLoss, self).__init__()
        if reduction not in ['none', 'mean', 'sum']:
            raise ValueError(f'Unsupported reduction mode: {reduction}. '
                             f'Supported ones are: {_reduction_modes}')

        self.loss_weight = loss_weight
        self.reduction = reduction
        self.eps = eps

    def forward(self, pred, target, weight=None, **kwargs):
        """
        Args:
            pred (Tensor): of shape (N, C, H, W). Predicted tensor.
            target (Tensor): of shape (N, C, H, W). Ground truth tensor.
            weight (Tensor, optional): of shape (N, C, H, W). Element-wise
                weights. Default: None.
        """
        return self.loss_weight * charbonnier_loss(
            pred, target, weight, eps=self.eps, reduction=self.reduction)


# class PerceptualLoss(nn.Module):
#     """Perceptual loss with commonly used style loss.

#     Args:
#         layer_weights (dict): The weight for each layer of vgg feature.
#             Here is an example: {'conv5_4': 1.}, which means the conv5_4
#             feature layer (before relu5_4) will be extracted with weight
#             1.0 in calculting losses.
#         vgg_type (str): The type of vgg network used as feature extractor.
#             Default: 'vgg19'.
#         use_input_norm (bool):  If True, normalize the input image in vgg.
#             Default: True.
#         perceptual_weight (float): If `perceptual_weight > 0`, the perceptual
#             loss will be calculated and the loss will multiplied by the
#             weight. Default: 1.0.
#         style_weight (float): If `style_weight > 0`, the style loss will be
#             calculated and the loss will multiplied by the weight.
#             Default: 0.
#         norm_img (bool): If True, the image will be normed to [0, 1]. Note that
#             this is different from the `use_input_norm` which norm the input in
#             in forward function of vgg according to the statistics of dataset.
#             Importantly, the input image must be in range [-1, 1].
#             Default: False.
#         criterion (str): Criterion used for perceptual loss. Default: 'l1'.
#     """

#     def __init__(self,
#                  layer_weights,
#                  vgg_type='vgg19',
#                  use_input_norm=True,
#                  perceptual_weight=1.0,
#                  style_weight=0.,
#                  norm_img=False,
#                  criterion='l1'):
#         super(PerceptualLoss, self).__init__()
#         self.norm_img = norm_img
#         self.perceptual_weight = perceptual_weight
#         self.style_weight = style_weight
#         self.layer_weights = layer_weights
#         #print('self.layer_weights', self.layer_weights)
#         self.vgg = VGGFeatureExtractor(
#             layer_name_list=list(layer_weights.keys()),
#             vgg_type=vgg_type,
#             use_input_norm=use_input_norm)

#         self.criterion_type = criterion
#         if self.criterion_type == 'l1':
#             self.criterion = torch.nn.L1Loss()
#         elif self.criterion_type == 'l2':
#             self.criterion = torch.nn.MSELoss() #L2loss()
#         elif self.criterion_type == 'fro':
#             self.criterion = None
#         else:
#             raise NotImplementedError(
#                 f'{criterion} criterion has not been supported.')

#     def forward(self, x, gt):
#         """Forward function.

#         Args:
#             x (Tensor): Input tensor with shape (n, c, h, w).
#             gt (Tensor): Ground-truth tensor with shape (n, c, h, w).

#         Returns:
#             Tensor: Forward results.
#         """

#         if self.norm_img:
#             x = (x + 1.) * 0.5
#             gt = (gt + 1.) * 0.5

#         # extract vgg features
#         x_features = self.vgg(x)
#         gt_features = self.vgg(gt.detach())

#         # calculate perceptual loss
#         if self.perceptual_weight > 0:
#             percep_loss = 0
#             for k in x_features.keys():
#                 if self.criterion_type == 'fro':
#                     percep_loss += torch.norm(
#                         x_features[k] - gt_features[k],
#                         p='fro') * self.layer_weights[k]
#                 else:
#                     percep_loss += self.criterion(
#                         x_features[k], gt_features[k]) * self.layer_weights[k]
#             percep_loss *= self.perceptual_weight
#         else:
#             percep_loss = None

#         # calculate style loss
#         if self.style_weight > 0:
#             style_loss = 0
#             for k in x_features.keys():
#                 if self.criterion_type == 'fro':
#                     style_loss += torch.norm(
#                         self._gram_mat(x_features[k]) -
#                         self._gram_mat(gt_features[k]),
#                         p='fro') * self.layer_weights[k]
#                 else:
#                     style_loss += self.criterion(
#                         self._gram_mat(x_features[k]),
#                         self._gram_mat(gt_features[k])) * self.layer_weights[k]
#             style_loss *= self.style_weight
#         else:
#             style_loss = None

#         return percep_loss, style_loss

#     def _gram_mat(self, x):
#         """Calculate Gram matrix.

#         Args:
#             x (torch.Tensor): Tensor with shape of (n, c, h, w).

#         Returns:
#             torch.Tensor: Gram matrix.
#         """
#         n, c, h, w = x.size()
#         features = x.view(n, c, w * h)
#         features_t = features.transpose(1, 2)
#         gram = features.bmm(features_t) / (c * h * w)
#         return gram

#-----------------------------------------------------------------------------
# define the perceptual loss
class VGG19(torch.nn.Module):
    def __init__(self, requires_grad=False):
        super().__init__()
        try:
            vgg_pretrained_features = torchvision.models.vgg19(
                weights=torchvision.models.VGG19_Weights.IMAGENET1K_V1).features
        except Exception:
            # SSL cert failure on some Python.org installs — retry with unverified context
            import ssl
            _orig = ssl._create_default_https_context
            ssl._create_default_https_context = ssl._create_unverified_context
            try:
                vgg_pretrained_features = torchvision.models.vgg19(
                    weights=torchvision.models.VGG19_Weights.IMAGENET1K_V1).features
            finally:
                ssl._create_default_https_context = _orig
        self.slice1 = torch.nn.Sequential()
        self.slice2 = torch.nn.Sequential()
        self.slice3 = torch.nn.Sequential()
        self.slice4 = torch.nn.Sequential()
        self.slice5 = torch.nn.Sequential()
        for x in range(2):
            self.slice1.add_module(str(x), vgg_pretrained_features[x])
        for x in range(2, 7):
            self.slice2.add_module(str(x), vgg_pretrained_features[x])
        for x in range(7, 12):
            self.slice3.add_module(str(x), vgg_pretrained_features[x])
        for x in range(12, 21):
            self.slice4.add_module(str(x), vgg_pretrained_features[x])
        for x in range(21, 30):
            self.slice5.add_module(str(x), vgg_pretrained_features[x])
        if not requires_grad:
            for param in self.parameters():
                param.requires_grad = False

    def forward(self, X):
        h_relu1 = self.slice1(X)
        h_relu2 = self.slice2(h_relu1)
        h_relu3 = self.slice3(h_relu2)
        h_relu4 = self.slice4(h_relu3)
        h_relu5 = self.slice5(h_relu4)
        out = [h_relu1, h_relu2, h_relu3, h_relu4, h_relu5]
        return out


class LPIPSLoss(nn.Module):
    """
    LPIPS perceptual loss — faithfully reproduces DarkIR's L_percep (Feijoo et al. 2025, Eq. 6:
    LPIPS based on VGG19). NOTE this is DIFFERENT from VGGLoss: LPIPS adds learned linear
    calibration on top of VGG features, whereas VGGLoss is a plain multi-layer VGG feature loss.
    Inputs assumed in [0,1]; LPIPS expects [-1,1].
    """

    def __init__(self, loss_weight=0.01, net='vgg'):
        super().__init__()
        import lpips as _lpips
        self.lpips = _lpips.LPIPS(net=net, verbose=False)
        for p in self.lpips.parameters():
            p.requires_grad_(False)
        self.weight = loss_weight

    def forward(self, x, y):
        return self.weight * self.lpips(x * 2 - 1, y * 2 - 1).mean()


class VGGLoss(nn.Module):
    def __init__(self, loss_weight=1.0, criterion = 'l1', reduction='mean'):
        super(VGGLoss, self).__init__()
        self.vgg = VGG19()
        if reduction not in ['none', 'mean', 'sum']:
            raise ValueError(f'Unsupported reduction mode: {reduction}. '
                             f'Supported ones are: {_reduction_modes}')


        if criterion == 'l1':
            self.criterion = nn.L1Loss(reduction=reduction)
        elif criterion == 'l2':
            self.criterion = nn.MSELoss(reduction=reduction)
        else:
            raise NotImplementedError('Unsupported criterion loss')
        
        self.weights = [1.0 / 32, 1.0 / 16, 1.0 / 8, 1.0 / 4, 1.0]
        self.weight = loss_weight

    def forward(self, x, y):
        x_vgg, y_vgg = self.vgg(x), self.vgg(y)
        loss = 0
        for i in range(len(x_vgg)):
            loss += self.weights[i] * self.criterion(x_vgg[i], y_vgg[i].detach())
        return self.weight * loss

#---------------------------------------------------------------
#define the edge loss to enhance the deblurring task
class EdgeLoss(nn.Module):
    def __init__(self, rank, loss_weight=1.0, criterion = 'l2',reduction='mean'):
        super(EdgeLoss, self).__init__()
        if reduction not in ['none', 'mean', 'sum']:
            raise ValueError(f'Unsupported reduction mode: {reduction}. '
                             f'Supported ones are: {_reduction_modes}')


        if criterion == 'l1':
            self.criterion = nn.L1Loss(reduction=reduction)
        elif criterion == 'l2':
            self.criterion = nn.MSELoss(reduction=reduction)
        else:
            raise NotImplementedError('Unsupported criterion loss')        

        k = torch.Tensor([[.05, .25, .4, .25, .05]])
        self.kernel = torch.matmul(k.t(),k).unsqueeze(0).repeat(3,1,1,1).to(rank)

        self.weight = loss_weight
        
                
    def conv_gauss(self, img):
        n_channels, _, kw, kh = self.kernel.shape
        img = F.pad(img, (kw//2, kh//2, kw//2, kh//2), mode='replicate')
        return F.conv2d(img, self.kernel, groups=n_channels)

    def laplacian_kernel(self, current):
        filtered    = self.conv_gauss(current)
        down        = filtered[:,:,::2,::2]
        new_filter  = torch.zeros_like(filtered)
        new_filter[:,:,::2,::2] = down*4
        filtered    = self.conv_gauss(new_filter)
        diff = current - filtered
        return diff

    def forward(self, x, y):
        loss = self.criterion(self.laplacian_kernel(x), self.laplacian_kernel(y))
        return loss*self.weight



def SSIM_loss(pred_img, real_img, data_range):
    SSIM_loss = pytorch_msssim.ssim(pred_img, real_img, data_range = data_range)
    return SSIM_loss

class SSIM(nn.Module):
    def __init__(self, loss_weight=1.0, data_range = 1.):
        super(SSIM, self).__init__()
        self.loss_weight = loss_weight
        self.data_range = data_range

    def forward(self, pred, target, **kwargs):
        return self.loss_weight * SSIM_loss(pred, target, self.data_range)

class SSIMloss(nn.Module):
    def __init__(self, loss_weight=1.0, data_range = 1.):
        super(SSIMloss, self).__init__()
        self.loss_weight = loss_weight
        self.data_range = data_range

    def forward(self, pred, target, **kwargs):
        return self.loss_weight * (1 - SSIM_loss(pred, target, self.data_range))

# class LPIPSloss(nn.Module):
#     def __init__(self, loss_weight=1.0, net_type='alex'):  # 'alex' | 'squeeze' | 'vgg'. Default: 'alex'.
#         super(LPIPSloss, self).__init__()
#         self.loss_weight = loss_weight
#         self.lpips_loss = LPIPS(net_type=net_type).eval()

#     def forward(self, pred, target, **kwargs):
#         self.lpips_loss = self.lpips_loss.to(pred.device)
#         return self.loss_weight * self.lpips_loss(pred, target)

class L1_Charbonnier_loss(nn.Module):
    """L1 Charbonnierloss."""
    def __init__(self):
        super(L1_Charbonnier_loss, self).__init__()
        self.eps = 1e-6

    def forward(self, X, Y):
        diff = torch.add(X, -Y)
        error = torch.sqrt(diff * diff + self.eps)
        loss = torch.mean(error)
        return loss
        
class L_deblur(nn.Module):
    """L_deblur."""
    def __init__(self, loss_weight=1.0, gamma1 = 0.4, gamma2 = 0.2, gamma3 = 0.2, gamma4 = 0.2):
        super(L_deblur, self).__init__()
        self.loss_weight = loss_weight
        self.gamma1 = gamma1
        self.gamma2 = gamma2
        self.gamma3 = gamma3
        self.gamma4 = gamma4

    def forward(self, X, Y):
        loss = self.gamma1 * l1_loss(X, Y) + self.gamma2 * mse_loss(X, Y) + self.gamma4 * SSIM_loss(X, Y)
        return self.loss_weight * loss

class L_enhance(nn.Module):
    """L_enhance."""
    def __init__(self, loss_weight=1.0, gamma1 = 0.5, gamma2 = 0.3, gamma3 = 0.2):
        super(L_enhance, self).__init__()
        self.loss_weight = loss_weight
        self.gamma1 = gamma1
        self.gamma2 = gamma2
        self.gamma3 = gamma3

    def forward(self, X, Y):
        loss = self.gamma1 * l1_loss(X, Y) + self.gamma2 * mse_loss(X, Y)
        return self.loss_weight * loss

class L_reblur(nn.Module):
    """L_enhance."""
    def __init__(self, loss_weight=1.0, gamma1 = 1.0):
        super(L_reblur, self).__init__()
        self.loss_weight = loss_weight
        self.gamma1 = gamma1

    def forward(self, X, Y):
        loss = self.gamma1 * l1_loss(X, Y)
        return self.loss_weight * loss
    
class EnhanceLoss(nn.Module):
    '''
    Applies the enhanceLoss. This loss is the l1 loss of the image downsampled at the middle of the
    encoder-decoder plus the l1 of the features of this downsample image given by the vgg19 (a perceptual
    element).
    '''
    def __init__(self, loss_weight=1.0, criterion = 'l1', reduction='mean'):
        super(EnhanceLoss, self).__init__()
        self.loss_weight = loss_weight
        if reduction not in ['none', 'mean', 'sum']:
            raise ValueError(f'Unsupported reduction mode: {reduction}. '
                             f'Supported ones are: {_reduction_modes}')

        if criterion == 'l1':
            self.criterion = nn.L1Loss(reduction=reduction)
        elif criterion == 'l2':
            self.criterion = nn.MSELoss(reduction=reduction)
        else:
            raise NotImplementedError('Unsupported criterion loss') 
        
        self.vgg19 = VGGLoss(loss_weight = 0.01,
                              criterion = criterion,
                              reduction = 'mean')
        
    def forward(self, gt, enhanced, scale_factor = 16):
        gt_low_res = F.interpolate(gt, scale_factor=scale_factor, mode = 'nearest')
        return self.vgg19(gt_low_res, enhanced) + self.loss_weight * self.criterion(gt_low_res, enhanced)


# ── Physics-guided loss functions ────────────────────────────────────────────

class RetinexLoss(nn.Module):
    """
    Physics-guided Retinex decomposition loss.

    Two terms:
      - TV smoothness on the estimated illumination map L.
      - Log-domain reflectance consistency: |log(R_pred) - log(R_target)|
        where R = S / L, estimated via max-pool over the brightest channel.

    Log domain is the natural Retinex space (Land & McCann, 1977) and gives
    uniform gradient magnitude across brightness levels — important for
    low-light inputs where linear-domain comparison biases toward bright pixels.

    eps=1e-4 (not 1e-6) to keep gradients stable for near-zero dark pixels.
    Training-only — zero inference overhead.
    """

    def __init__(self, weight=0.1, pool_kernel=15, smooth_weight=0.5, recon_weight=0.5):
        super().__init__()
        self.weight        = weight
        self.smooth_weight = smooth_weight
        self.recon_weight  = recon_weight
        pad = pool_kernel // 2
        self.pool = nn.MaxPool2d(pool_kernel, stride=1, padding=pad)

    def forward(self, x_pred, target):
        eps = 1e-4

        L_pred   = self.pool(x_pred.max(dim=1, keepdim=True).values).clamp(min=eps)
        L_target = self.pool(target.max(dim=1, keepdim=True).values).clamp(min=eps)

        # TV smoothness on predicted illumination map
        smooth_h = torch.abs(L_pred[:, :, 1:, :] - L_pred[:, :, :-1, :]).mean()
        smooth_w = torch.abs(L_pred[:, :, :, 1:] - L_pred[:, :, :, :-1]).mean()

        # Log-domain reflectance comparison: log(R) = log(S) - log(L)
        log_R_pred   = torch.log(x_pred  + eps) - torch.log(L_pred.expand_as(x_pred)   + eps)
        log_R_target = torch.log(target  + eps) - torch.log(L_target.expand_as(target) + eps)
        recon = F.l1_loss(log_R_pred, log_R_target)

        return self.weight * (self.smooth_weight * (smooth_h + smooth_w) + self.recon_weight * recon)


class BlurAwareGradientLoss(nn.Module):
    """
    Blur-aware gradient loss with a learnable Gaussian PSF.

    Enforces: ||grad(x_pred ⊗ k_est) - grad(y_input)||_1
    PSF sigma is a trainable parameter updated alongside model weights.
    Training-only — zero inference overhead.
    """

    def __init__(self, weight=0.05, init_sigma=1.5, kernel_size=11, normalize=False):
        super().__init__()
        self.weight      = weight
        self.kernel_size = kernel_size
        # normalize=False reproduces the originally-reported formulation EXACTLY and is the
        # default, so every result already in the thesis is bit-identical under this file.
        #
        # Why the option exists: the unnormalised form compares grad(blur(pred)) against
        # grad(input), but `pred` is illumination-corrected and `input` is not. Sobel
        # magnitude scales with intensity, so the residual is dominated by the brightness gap
        # rather than by blur, and sigma -- the only free parameter that can shrink the left
        # side -- inflates to its clamp regardless of the true blur. Measured on synthetic
        # content with a known true sigma of 1.5: the unnormalised loss recovers 1.50 when
        # prediction and input share an intensity scale, but returns 3.50 at half intensity
        # and pins at the 5.0 clamp at quarter intensity and below.
        # Normalising each gradient map by its own spatial mean makes the comparison
        # scale-invariant, which removes the confound: sigma* = 1.50 at every intensity.
        self.normalize   = normalize
        self.log_sigma   = nn.Parameter(torch.tensor(float(init_sigma)).log())
        sx = torch.tensor([[-1., 0., 1.], [-2., 0., 2.], [-1., 0., 1.]])
        sy = torch.tensor([[-1., -2., -1.], [0., 0., 0.], [1., 2., 1.]])
        self.register_buffer('sobel_x', sx.view(1, 1, 3, 3))
        self.register_buffer('sobel_y', sy.view(1, 1, 3, 3))

    def _gaussian_kernel(self, device):
        sigma  = self.log_sigma.exp().clamp(0.3, 5.0)
        k      = self.kernel_size
        coords = torch.arange(k, dtype=torch.float32, device=device) - k // 2
        g1d    = torch.exp(-0.5 * (coords / sigma) ** 2)
        g2d    = g1d.unsqueeze(0) * g1d.unsqueeze(1)
        return (g2d / g2d.sum()).view(1, 1, k, k)

    def _sobel(self, x):
        B, C, H, W = x.shape
        xf = x.view(B * C, 1, H, W)
        gx = F.conv2d(xf, self.sobel_x, padding=1)
        gy = F.conv2d(xf, self.sobel_y, padding=1)
        return (gx ** 2 + gy ** 2 + 1e-8).sqrt().view(B, C, H, W)

    def _blur(self, x):
        B, C, H, W = x.shape
        k = self._gaussian_kernel(x.device).expand(C, 1, self.kernel_size, self.kernel_size)
        return F.conv2d(x, k, padding=self.kernel_size // 2, groups=C)

    def forward(self, x_pred, y_input):
        gp = self._sobel(self._blur(x_pred))
        gy = self._sobel(y_input)
        if self.normalize:
            # per-sample spatial mean, so the scale cancels on both sides independently
            gp = gp / gp.mean(dim=(1, 2, 3), keepdim=True).clamp_min(1e-6)
            gy = gy / gy.mean(dim=(1, 2, 3), keepdim=True).clamp_min(1e-6)
        return self.weight * F.l1_loss(gp, gy)


class PhaseEnhancedFrequencyLoss(nn.Module):
    """
    Extends amplitude-only frequency loss with explicit phase-gradient supervision.

    A high-pass mask suppresses DC/near-DC where phase is unreliable.
    Phase is represented as unit complex vectors to avoid 2π wrapping issues.
    Training-only — zero inference overhead.
    """

    def __init__(self, weight=0.05, amp_weight=0.5, phase_weight=0.5, high_pass_ratio=0.1):
        super().__init__()
        self.weight          = weight
        self.amp_weight      = amp_weight
        self.phase_weight    = phase_weight
        self.high_pass_ratio = high_pass_ratio

    @staticmethod
    def _phase_unit(fft_tensor):
        return fft_tensor / fft_tensor.abs().clamp(min=1e-8)

    @staticmethod
    def _freq_grad(p):
        return p[:, :, 1:, :] - p[:, :, :-1, :], p[:, :, :, 1:] - p[:, :, :, :-1]

    def _high_pass_mask(self, shape, device):
        _, _, H, Wr = shape
        mask = torch.ones(1, 1, H, Wr, device=device)
        rh   = max(1, int(H  * self.high_pass_ratio))
        rw   = max(1, int(Wr * self.high_pass_ratio))
        mask[:, :, :rh, :rw] = 0.0
        return mask

    def forward(self, pred, target):
        # rfft2 is unsupported on some backends (e.g. MPS); route through CPU when
        # not on CUDA. .cpu() on a CPU tensor is a no-op so the CPU path is unaffected.
        dev = pred.device
        if pred.is_cuda:
            pf = torch.fft.rfft2(pred,        norm='backward')
            tf = torch.fft.rfft2(target,      norm='backward')
        else:
            pf = torch.fft.rfft2(pred.cpu(),  norm='backward').to(dev)
            tf = torch.fft.rfft2(target.cpu(),norm='backward').to(dev)
        mask = self._high_pass_mask(pf.shape, pf.device)

        amp_loss = F.l1_loss(pf.abs() * mask, tf.abs() * mask)

        pp, tp   = self._phase_unit(pf), self._phase_unit(tf)
        pdh, pdw = self._freq_grad(pp)
        tdh, tdw = self._freq_grad(tp)
        phase_loss = (
            F.l1_loss(pdh.real * mask[:, :, 1:, :], tdh.real * mask[:, :, 1:, :]) +
            F.l1_loss(pdw.real * mask[:, :, :, 1:], tdw.real * mask[:, :, :, 1:])
        )
        return self.weight * (self.amp_weight * amp_loss + self.phase_weight * phase_loss)

